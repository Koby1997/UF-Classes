#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include "process_log.h"

int get_proc_log_level()
{
	return syscall(435);
}

int set_proc_log_level(int level)
{
	return syscall(436, level);
}

int proc_log_message(int level, char *message)
{
	return syscall(437, level, message);
}

