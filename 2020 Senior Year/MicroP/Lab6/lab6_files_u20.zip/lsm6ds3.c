/*------------------------------------------------------------------------------
  lsm6ds3.c --
  
  Description:
    Brief description of file.
	  
	  Extended description, if appropriate.
  
  Author(s):
  Last modified by: 
  Last modified on: DD Month YYYY
------------------------------------------------------------------------------*/

/********************************DEPENDENCIES**********************************/

#include <avr/io.h>
#include "lsm6ds3.h"
#include "lsm6ds3_registers.h"

/*****************************END OF DEPENDENCIES******************************/


/*****************************FUNCTION DEFINITIONS*****************************/

/* INSERT YOUR LSM6DS3 FUNCTION DEFINITIONS BELOW. */

/***************************END OF FUNCTION DEFINITIONS************************/