#include <string>

using namespace std;

char *read_file(const char *filename);
string displayfile(const char *filename);
