int get_proc_log_level(void);
int set_proc_log_level(int new_level);
int proc_log_message(int level, char *message);
